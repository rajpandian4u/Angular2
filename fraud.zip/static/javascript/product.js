(function() {
	var app = angular.module('store-products', []);
	
	app.controller('PanelController', function() {
		this.tab = 1;
		this.selectTab = function(setTab) {
			this.tab = setTab;
		}
		
		this.isSelected = function(checkTab) {
			return (this.tab == checkTab)
		}
	});
	
	app.controller('ReviewController', function() {
		this.review = {};
		
		this.addReview = function(product) {
			product.comments.push(this.review);
			this.review={};
		}
	});
	
	app.directive('notYet', function() {
		 return {
			template: '<h4>Specifications</h4><blockquote>None Yet</blockquote>'
		};
	});
	
	app.directive('productReview', function() {
		return {
			template: '<b>{{comment.stars}}</b><br/><cite>{{comment.review | limitTo:100}}</cite><br/>--<cite>{{comment.name | uppercase}}</cite><br/>'
		};
	});
	
	app.directive('productPanels', function() {
		return {
			restrict: 'E',
			templateUrl: 'product-panels.html',
			controllerAs: 'panels'
		};
		
	});
	
	app.directive('myCurrentTime', ['$interval', 'dateFilter', function($interval, dateFilter) {
		function link(scope, element, attrs) {
			var format,
			timeoutId;

			function updateTime() {
				element.text(dateFilter(new Date(), format));
			}

			scope.$watch(attrs.myCurrentTime, function(value) {
				format = value;
				updateTime();
			});

			element.on('$destroy', function() {
				$interval.cancel(timeoutId);
			});

			// start the UI update process; save the timeoutId for canceling
			timeoutId = $interval(function() {
				updateTime(); // update DOM
			}, 1000);
		}
		
		return {
			link: link
		};
	}]);
})();