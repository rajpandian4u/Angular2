(function(angular) {
	'use strict';
	var app = angular.module('miReportDetailsApp', ['ngRoute']);
	app.controller('MIDetailsController', ['$http', '$scope', '$route', '$routeParams', '$location', function($http, $scope, $route, $routeParams, $location) {
		var miSSNSummary = this;
		miSSNSummary.prevCriteriaTypeCode = '';
		miSSNSummary.miParms = $location.search();
		
		miSSNSummary.domain = {
				reportId: miSSNSummary.miParms.reportId,
				parentReportId: miSSNSummary.miParms.parentReportId,
				reportType: miSSNSummary.miParms.reportType,
				reportPeriod: miSSNSummary.miParms.reportPeriod,
				reportStatusCode: miSSNSummary.miParms.reportStatusCode,
				reportCreatedDateTime: miSSNSummary.miParms.reportCreatedDateTime
		};
		
		
		miSSNSummary.restURL = '/PFIRAngularWeb/rest/miRestService/viewSSNSummaryMI';
		$http({
			method: 'POST',
			url: miSSNSummary.restURL,
			headers: {
				   'Content-Type': 'application/json'
			},
			data: miSSNSummary.domain
		})
		.success(function(data, status, headers, config) {
			miSSNSummary.ssnSummaryList = data;
		})
		.error(function (data, status) {
            alert('Inner Error');
        });
	}]);
	
	app.config(function($routeProvider, $locationProvider) {
		$locationProvider.html5Mode(true);
	});
	
	app.directive('prevCriteriaType', function() {
		alert();
	});
})(window.angular);