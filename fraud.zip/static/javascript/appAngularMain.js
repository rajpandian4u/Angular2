(function(angular) {
	'use strict';
	var app = angular.module('miReportApp', ['ngRoute','mgcrea.ngStrap','ngTouch', 'ui.grid', 'ui.grid.pagination']);
	app.controller('MIMainController', ['$window','$scope', '$http', '$q', '$location', '$route', '$routeParams', function($window, $scope, $http, $q, $location, $route, $routeParams) {
		var miReport = this;
		this.currDate = Date.now();
		this.errorMessages = [];
		var miColumnDef = [
		                   	{name: 'reportId', field: 'reportId', displayName: 'Report ID', width: '10%', type: 'number', leftPad:'10%'
		                   		, sort: {
		                   			    direction: 'ASC',
		                   			    ignoreSort: true,
		                   			    priority: 0
		                   			}
		                   		, cellTemplate: 
		                   				  '<div>'
		                   				+ '<a class="ngCellText" ng-class="col.colIndex()" ng-show="row.entity.reportStatusCode==\'C\'"' 
		                   				//+ 'target="_self" ng-href="/PFIRAngularWeb/rest/miRestService/selectReport?reportId={{COL_FIELD}}" >'
		                   				+ ' ng-click="grid.appScope.miController.viewReport(COL_FIELD, row.entity.parentReportId, row.entity.reportType, row.entity.reportPeriod, row.entity.reportStatusCode, row.entity.reportCreatedDateTime)">'
		                   				+ '{{COL_FIELD}}</a>'
		                   				+ '<label ng-show="row.entity.reportStatusCode!=\'C\'">{{COL_FIELD}}</label>'
		                   				+ '</div>'
		                   	},
		                   	{name: 'parentReportId', field: 'parentReportId', displayName: 'Parent Report Id', visible:false},
					    	{name: 'reportType', field: 'reportType', displayName: 'Report Type', width: '35%'},
					    	{name: 'reportCreatedDateTime', field: 'reportCreatedDateTime', displayName: 'Created Date/Time'},
					    	{name: 'reportPeriod', field: 'reportPeriod', displayName: 'Report Period', width: '25%'},
					    	{name: 'reportStatus', field: 'reportStatus', displayName: 'Report Status'},
					    	{name: 'reportStatusCode', field: 'reportStatusCode', displayName: 'Report Status Code', visible: false, width: '10%'},
					    ];
		this.gridOptions1 = {
			    	paginationPageSizes: [25, 50, 75],
			    	paginationPageSize: 25,
			    	columnDefs: miColumnDef,
			    	enableRowSelection: true,
			    	enableRowHeaderSelection: false,
			    	enableFiltering: true,
			  		};
		initMI(true);
		
		 this.gridOptions1.multiSelect = false;
		 this.gridOptions1.modifierKeysToMultiSelect = false;
		 this.gridOptions1.noUnselect = true;
		 this.gridOptions1.onRegisterApi = function( gridApi ) {
			 miReport.gridApi = gridApi;
		 };

		 
		function initMI(isResetData) {
			$http({
				method: 'GET',
				url: '/initMI',
				params: {
					name: 'Hi I am Here'
	            }

			})
			.success(function(data, status, headers, config) {
				miReport.gridOptions1.data = data["reportsSummaryList"];
				if(isResetData) {
					miReport.fiscalYearList = data["fiscalYearList"];
					miReport.calendarYearList = data["calendarYearList"]; 
					miReport.calendarQuarterList = data["calendarQuarterList"];
					miReport.calendarMonthList = data["calendarMonthList"];
					miReport.calendarWeekList = data["calendarWeekList"];
					miReport.domain = data["miReportsDomain"];
					resetMIData();
				}
			})
			.error(function (data, status) {
	            alert(error);
	        });
		};
		
		this.viewReport = function(reportId, parentReportId, reportType, reportPeriod, reportStatusCode, reportCreatedDateTime) {
			//window.location = '../deeplink/index.html?reportId='+reportId
			window.location = 'miReportSSNDetails.jsp?reportId='+reportId 
																+ '&parentReportId=' + parentReportId
			 													+ '&reportType=' + reportType
			 													+ '&reportPeriod=' + reportPeriod
			 													+ '&reportCreatedDateTime=' + reportCreatedDateTime
			 													+ '&reportStatusCode=' + reportStatusCode;
		};
		
		this.generateMI = function() {
			miReport.isError = false;
			miReport.isInfo = false;
			if(!validateMI()) {
				var restURL = '/generateMI';
				handleMI(restURL);
				miReport.isSuccess = true;
				return true;
			} else {
				return false;
			}
			
		};
		
		this.refreshMI = function() {
			initMI(false);
			miReport.isSuccess = false;
			miReport.isInfo = true;
			miReport.isError = false;
		};
		
		function handleMI(restURL) {
			if(typeof miReport.calendarQuarterEnding != 'undefined') {
				miReport.domain.calendarQuarterEnding = miReport.calendarQuarterEnding.key;
			}
			
			if(typeof miReport.calendarMonthEnding != 'undefined') {
				miReport.domain.calendarMonthEnding = miReport.calendarMonthEnding.key;
			}
			
			if(typeof miReport.calendarWeekEnding != 'undefined') {
				miReport.domain.calendarWeekEnding = miReport.calendarWeekEnding.key;
			}
			
			$http({
				method: 'POST',
				url: restURL,
				headers: {
					   'Content-Type': 'application/json'
				},
				data: miReport.domain
			})
			.success(function(data, status, headers, config) {
				miReport.miList = data;
				miReport.gridOptions1.data = data["reportsSummaryList"];
			})
			.error(function (data, status) {
	            alert('Inner Error');
	        });
		};
		
		function validateMI() {
			var domain = miReport.domain;
			miReport.errorMessages = [];
			
			if(domain.reportType == 'A') {
		        if(false == domain.criteriaTypeMyDD && false == domain.criteriaTypeOthers && false == domain.criteriaTypeISSNRC) {
		        	miReport.errorMessages.push('No Activity type selected. Please select at least one of MyDD or Other or iSSNRC');
	                miReport.isError = true;
		        }
			}
			
			if(typeof miReport.calendarQuarterEnding != 'undefined') {
				miReport.domain.calendarQuarterEnding = miReport.calendarQuarterEnding.key;
			}
			
			if(typeof miReport.calendarMonthEnding != 'undefined') {
				miReport.domain.calendarMonthEnding = miReport.calendarMonthEnding.key;
			}
			
			if(typeof miReport.calendarWeekEnding != 'undefined') {
				miReport.domain.calendarWeekEnding = miReport.calendarWeekEnding.key;
			}
			
		    if('FY' == domain.timeFrame && null == domain.fiscalYear) {
		    	miReport.errorMessages.push('Fiscal Year is required');
                miReport.isError = true;
	        } else if('CY' == domain.timeFrame && null == domain.calendarYear) {
	        	miReport.errorMessages.push('Calendar Year is required');
                miReport.isError = true;
	        } else if('CQ' == domain.timeFrame &&  null == domain.calendarQuarterEnding) {
	        	miReport.errorMessages.push(' Calendar Quarter Ending is required');
                miReport.isError = true;
	        } else if('CM' == domain.timeFrame && null == domain.calendarMonthEnding) {
	        	miReport.errorMessages.push('Calendar Month Ending  is required');
                miReport.isError = true;
	        } else if('CW' == domain.timeFrame && null == domain.calendarWeekEnding) {
	        	miReport.errorMessages.push('Calendar Week Ending  is required');
                miReport.isError = true;
	        } else if('SD' == domain.timeFrame && null == domain.selectedDate) {
	        	miReport.errorMessages.push('Selected Date is required');
                miReport.isError = true;
	        } else if('DR' == domain.timeFrame && (null == domain.startDate || null == domain.endDate)) {
	        	miReport.errorMessages.push('Date Range is required');
                miReport.isError = true;
	        }
		    
		    return miReport.isError;
		}
		
		function resetMIData() {
			miReport.domain.reportType = 'A';
			miReport.domain.criteriaTypeMyDD = true;
			miReport.domain.criteriaTypeOthers = true;
			miReport.domain.criteriaTypeISSNRC = true;
			miReport.domain.timeFrame = 'FY';
			miReport.errorMessages = [];
			miReport.isSuccess = false;
			miReport.isInfo = false;
			miReport.isError = false;
		};
	}]);
	
	app.config(function($datepickerProvider, $routeProvider, $locationProvider) {
		angular.extend($datepickerProvider.defaults, {
		    dateFormat: 'MM/dd/yyyy',
		    dateonly:true,
		    startWeek: 1,
		    link: function(scope, element, attr, controller) {
		        //remove the default formatter from the input directive to prevent conflict
		        controller.$formatters.shift();
		    }
		});
		
		$routeProvider
			.when('/ViewReport/:reportId', {
				templateUrl : 'http://localhost:9080/PFIRAngularWeb/jsp/Data_Table3/index.html',
				controller : 'MIMainController',
			}) .when('/Book/:bookId/ch/:chapterId', {
				templateUrl : 'chapter.html',
				controller : 'ChapterController'
			}) .when('/Book/:bookId/pg/:pageNo', {
				templateUrl : 'page.html',
				controller : 'PageController'
			}) ;
		// configure html5 to get links working on jsfiddle
		$locationProvider.html5Mode(true);
	});
})(window.angular);