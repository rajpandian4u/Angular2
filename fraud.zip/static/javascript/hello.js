(function() {
	var app = angular.module('helloApp', ['store-products']);
	app.controller('HelloControllers', ['$http', '$q', function($http, $q, helloService) {alert($q);
		this.currDate = Date.now();
		//this.products = items;
		this.value1 = 1;
		this.value2 = 1;
		this.result = this.value1 + this.value2;
		
		var store = this;
		//store.products = [];
		
		//$http.get('/AngularSamplerWeb/rest/hello')
		$http({
				method: 'GET',
				url: '/AngularSamplerWeb/rest/hello/request',
				params: {
					name: 'Hi I am Here'
                }

			})
			.success(function(data, status, headers, config) {
				store.products = data;
				
			})
			.error(function (data, status) {
	            alert("Error");
	        }
		);
		
		/*$http({method: 'GET', url: '/AngularSamplerWeb/rest/hello'})
			.success(function(data, status, headers, config) {
				alert(data);

			})
			.error(function(data, status, headers, config) {
				alert("Error");
			});*/
		
		this.addValues = function() {
			this.result = parseInt(this.value1) + parseInt(this.value2);
			return {
				templateUrl: 'product-panels.html'
			};
		};
	}]);
	
	var items = [
					{name: 'Tread Mill', description:'A treadmill is a device generally for walking or running while staying in the same place.',
								comments: [
											{
												name: 'Glen',
												review: 'It\'s really awesome',
												stars: 4,
											},
											{
												name: 'Mathew',
												review: 'It\'s really good',
												stars: 3,
											}
										],
								price:1400.25, positive:true, imagePath:'../../images/treadmill.jpg'},
					{name: 'Elliptical', description:'An elliptical trainer or cross-trainer is a stationary exercise machine used to simulate stair climbing, walking, or running without causing excessive pressure to the joints, hence decreasing the risk of impact injuries.',
								comments: [
											{
												name: 'Adam',
												review: 'It\'s OK',
												stars: 2,
											},
											{
												name: 'Ricky',
												review: 'It\'s really cool',
												stars: 5,
											}
										],
								price:800.7, positive:true, imagePath:'../../images/elliptical.jpg'}
				];
})();