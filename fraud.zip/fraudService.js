var express = require('express');
var fraudDAO = require('./fraudDAO');

exports.initMI = function(req, res) {
	console.log("Init MI Begin:");
	fraudDAO.findReports(res, finishInitMI);
	console.log("Init MI End:");
}

function finishInitMI(res, reportsSummaryList) {
	var initData = {};
	initData.fiscalYearList = fraudDAO.getFiscalYears();
	initData.calendarYearList = fraudDAO.getCalendarYears();
	initData.calendarQuarterList = fraudDAO.getCalendarQuarter();
	initData.calendarMonthList = fraudDAO.getCalendarMonth();
	initData.calendarWeekList = fraudDAO.getCalendarWeek();
	initData.miReportsDomain = {};
	initData.reportsSummaryList = reportsSummaryList;
	res.json(initData);
}

exports.generateMI = function(req, res) {
	console.log('\nGenerate MI started:');
	var requestData = req.body;
	
	var insertData = {
		reportType: requestData.reportType,
		timeFrame: requestData.timeFrame,
		criteriaTypes: {
			criteriaTypeMyDD: requestData.criteriaTypeMyDD,
			criteriaTypeOthers: requestData.criteriaTypeOthers,
			criteriaTypeISSNRC: requestData.criteriaTypeISSNRC,
		},
		insertTimeStamp: new Date().toJSON(),
		reportStatusCd: 'S',
		requestorPin: 'temp'
	};
	
	if(insertData.timeFrame == 'FY') {
		insertData.timeFrameValue = requestData.fiscalYear;
	} else if(insertData.timeFrame == 'CY') {
		insertData.timeFrameValue = requestData.calendarYear;
	} else if(insertData.timeFrame == 'CQ') {
		insertData.timeFrameValue = requestData.calendarQuarterEnding;
	} else if(insertData.timeFrame == 'CM') {
		insertData.timeFrameValue = requestData.calendarMonthEnding;
	} else if(insertData.timeFrame == 'CW') {
		insertData.timeFrameValue = requestData.calendarWeekEnding;
	} else if(insertData.timeFrame == 'SD') {
		insertData.timeFrameValue = requestData.selectedDate;
	} else if(insertData.timeFrame == 'DR') {
		insertData.timeFrameValueStart = requestData.startDate;
		insertData.timeFrameValueEnd = requestData.endDate;
	}
	
	fraudDAO.handleMIInsert(res, insertData, finishInitMI);
	console.log('\nGenerate MI completed:');
}