var express = require('express');
var bodyParser = require('body-parser');

var app = express();

module.exports = function(app) {
	app.use(bodyParser());
	var fraudService = require('./fraudService');
	
	app.get('/initMI', fraudService.initMI);
	app.post('/generateMI', fraudService.generateMI);
}