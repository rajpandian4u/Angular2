var MongoClient = require('mongodb').MongoClient;

var rptcntlColl;
var countersColl;
var dbConn = require('./dbUtil');
dbConn.getDBConnection(function(db) {
	rptcntlColl = db.collection('rptcntl');
	countersColl = db.collection('counters');
});

exports.findReports = function(res, callback) {
	console.log("retrieveReports Start:");
	retrieveReports(res, callback)
	console.log("retrieveReports End:");
}

function retrieveReports(res, callback) {
	var query = {};
	var sorter = [['reportId', -1]];
	var cursor = rptcntlColl.find(query);
	cursor = cursor.sort(sorter);
	var reportsList = displayRptcntlCursor(cursor, res, callback);
}

function displayRptcntlCursor(cursor, res, callback) {
	var reportList = [];
	
	cursor.toArray(function(err, itemArr) {
		for (var i in itemArr) {
			var reportData = {
				reportId: itemArr[i].reportId,
				reportType: itemArr[i].reportType,
				timeFrame: itemArr[i].timeFrame,
				criteriaTypes: itemArr[i].criteriaTypes,
				reportCreatedDateTime: itemArr[i].insertTimeStamp,
				reportStatusCode: itemArr[i].reportStatusCd
			};
			
			if(reportData.reportStatusCode == 'S') {
				reportData.reportStatus = 'Selected';
			} else if(reportData.reportStatusCode == 'I') {
				reportData.reportStatus = 'In Progress';
			} else if(reportData.reportStatusCode == 'C') {
				reportData.reportStatus = 'Completed';
			} else if(reportData.reportStatusCode == 'F') {
				reportData.reportStatus = 'Failed';
			}
			
			if(itemArr[i].timeFrame == 'FY') {
				reportData.reportPeriod = 'Fiscal Year ' + itemArr[i].timeFrameValue;
			} else if(itemArr[i].timeFrame == 'CY') {
				reportData.reportPeriod = 'Calendar Year ' + itemArr[i].timeFrameValue;
			} else if(itemArr[i].timeFrame == 'CQ') {
				reportData.reportPeriod = 'Calendar Quarter Ending ' + itemArr[i].timeFrameValue;
			} else if(itemArr[i].timeFrame == 'CM') {
				reportData.reportPeriod = 'Calendar Month Ending ' + itemArr[i].timeFrameValue;
			} else if(itemArr[i].timeFrame == 'CW') {
				reportData.reportPeriod = 'Calendar Week Ending ' + itemArr[i].timeFrameValue;
			} else if(itemArr[i].timeFrame == 'SD') {
				reportData.reportPeriod = 'Selected date ' + itemArr[i].timeFrameValue;
			} else if(itemArr[i].timeFrame == 'DR') {
				reportData.reportPeriod = 'Date Range ' + itemArr[i].timeFrameValueStart + ' to ' + itemArr[i].timeFrameValueEnd;
			}
			
			if(itemArr[i].reportType == 'A') {
				var isFirst = true;
				reportData.reportType = 'ACTIVITY SUMMARY MI REPORT (';
				if(itemArr[i].criteriaTypes.criteriaTypeMyDD == true) {
					reportData.reportType += 'MYDD';
					isFirst = false;
				}
				
				if(itemArr[i].criteriaTypes.criteriaTypeOthers == true) {
					if(!isFirst) {
						reportData.reportType += ', ';
					}
					reportData.reportType += 'Others';
					isFirst = false;
				}
				
				if(itemArr[i].criteriaTypes.criteriaTypeISSNRC == true) {
					if(!isFirst) {
						reportData.reportType += ', ';
					}
					reportData.reportType += 'ISSNRC';
					isFirst = false;
				}
				
				reportData.reportType += ')';
			} else {
				reportData.reportType = 'SSN SUMMARY MI REPORT'
			}
			reportList.push(reportData);
		}
		
		callback(res, reportList);
	});
}

exports.handleMIInsert = function(res, insertData, callbackFinish) {
	getNextSequence(res, insertData, 'reportid', insertRptcntl, retrieveReports, callbackFinish);
}
	
function getNextSequence(res, insertData, name, callbackInsert, callbackFind, callbackFinish) {
	var ret = {};
	
	countersColl.findAndModify(
		{ _id: name },
		[],
		{ $inc: { "seq": 1 } },
		{ upsert: true, new: true },
		function(err, doc, results) {
			ret = doc.value;
			callbackInsert(res, insertData, doc.value.seq, callbackFind, callbackFinish);
		}
	);
}

function insertRptcntl(res, insertData, reportId, callbackFind, callbackFinish) {
	insertData.reportId = reportId;
	var options = {w:1, wtimeout:5000, journal:true};
	rptcntlColl.insert([insertData], options, function(err, results) {
		callbackFind(res, callbackFinish);
	});
}

exports.getFiscalYears = function() {
	var fiscalYears = ["2016","2015","2014","2013","2012"];
	//console.log("Fiscal Years: " + fiscalYears);
	return fiscalYears;
}

exports.getCalendarYears = function() {
	var calendarYearList = ["2016","2015","2014","2013"];
	//console.log("Current Years: " + JSON.stringify(calendarYearList));
	return calendarYearList;
}

exports.getCalendarQuarter = function() {
	var listData = [{"key":"2016-03-31","value":"Mar 31, 2016"},{"key":"2015-12-31","value":"Dec 31, 2015"},{"key":"2015-09-30","value":"Sep 30, 2015"},{"key":"2015-06-30","value":"Jun 30, 2015"},{"key":"2015-03-31","value":"Mar 31, 2015"},{"key":"2014-12-31","value":"Dec 31, 2014"},{"key":"2014-09-30","value":"Sep 30, 2014"},{"key":"2014-06-30","value":"Jun 30, 2014"},{"key":"2014-03-31","value":"Mar 31, 2014"},{"key":"2013-12-31","value":"Dec 31, 2013"},{"key":"2013-09-30","value":"Sep 30, 2013"}];
	//console.log("Current Quarter: " + JSON.stringify(listData));
	return listData;
}

exports.getCalendarMonth = function() {
	var listData = [{"key":"2016-03-31","value":"Mar 31, 2016"},{"key":"2016-02-29","value":"Feb 29, 2016"},{"key":"2016-01-31","value":"Jan 31, 2016"},{"key":"2015-12-31","value":"Dec 31, 2015"},{"key":"2015-11-30","value":"Nov 30, 2015"},{"key":"2015-10-31","value":"Oct 31, 2015"},{"key":"2015-09-30","value":"Sep 30, 2015"},{"key":"2015-08-31","value":"Aug 31, 2015"},{"key":"2015-07-31","value":"Jul 31, 2015"},{"key":"2015-06-30","value":"Jun 30, 2015"},{"key":"2015-05-31","value":"May 31, 2015"},{"key":"2015-04-30","value":"Apr 30, 2015"},{"key":"2015-03-31","value":"Mar 31, 2015"},{"key":"2015-02-28","value":"Feb 28, 2015"},{"key":"2015-01-31","value":"Jan 31, 2015"},{"key":"2014-12-31","value":"Dec 31, 2014"},{"key":"2014-11-30","value":"Nov 30, 2014"},{"key":"2014-10-31","value":"Oct 31, 2014"},{"key":"2014-09-30","value":"Sep 30, 2014"},{"key":"2014-08-31","value":"Aug 31, 2014"},{"key":"2014-07-31","value":"Jul 31, 2014"},{"key":"2014-06-30","value":"Jun 30, 2014"},{"key":"2014-05-31","value":"May 31, 2014"},{"key":"2014-04-30","value":"Apr 30, 2014"},{"key":"2014-03-31","value":"Mar 31, 2014"},{"key":"2014-02-28","value":"Feb 28, 2014"},{"key":"2014-01-31","value":"Jan 31, 2014"},{"key":"2013-12-31","value":"Dec 31, 2013"},{"key":"2013-11-30","value":"Nov 30, 2013"},{"key":"2013-10-31","value":"Oct 31, 2013"},{"key":"2013-09-30","value":"Sep 30, 2013"},{"key":"2013-08-31","value":"Aug 31, 2013"}];
	//console.log("Current Month: " + JSON.stringify(listData));
	return listData;
}

exports.getCalendarWeek = function() {
	var listData = [{"key":"2016-03-05","value":"Mar 05, 2016"},{"key":"2016-02-27","value":"Feb 27, 2016"},{"key":"2016-02-20","value":"Feb 20, 2016"},{"key":"2016-02-13","value":"Feb 13, 2016"},{"key":"2016-02-06","value":"Feb 06, 2016"},{"key":"2016-01-30","value":"Jan 30, 2016"},{"key":"2016-01-23","value":"Jan 23, 2016"},{"key":"2016-01-16","value":"Jan 16, 2016"},{"key":"2016-01-09","value":"Jan 09, 2016"},{"key":"2016-01-02","value":"Jan 02, 2016"},{"key":"2015-12-26","value":"Dec 26, 2015"},{"key":"2015-12-19","value":"Dec 19, 2015"},{"key":"2015-12-12","value":"Dec 12, 2015"},{"key":"2015-12-05","value":"Dec 05, 2015"},{"key":"2015-11-28","value":"Nov 28, 2015"},{"key":"2015-11-21","value":"Nov 21, 2015"},{"key":"2015-11-14","value":"Nov 14, 2015"},{"key":"2015-11-07","value":"Nov 07, 2015"},{"key":"2015-10-31","value":"Oct 31, 2015"},{"key":"2015-10-24","value":"Oct 24, 2015"},{"key":"2015-10-17","value":"Oct 17, 2015"},{"key":"2015-10-10","value":"Oct 10, 2015"},{"key":"2015-10-03","value":"Oct 03, 2015"},{"key":"2015-09-26","value":"Sep 26, 2015"},{"key":"2015-09-19","value":"Sep 19, 2015"},{"key":"2015-09-12","value":"Sep 12, 2015"},{"key":"2015-09-05","value":"Sep 05, 2015"},{"key":"2015-08-29","value":"Aug 29, 2015"},{"key":"2015-08-22","value":"Aug 22, 2015"},{"key":"2015-08-15","value":"Aug 15, 2015"},{"key":"2015-08-08","value":"Aug 08, 2015"},{"key":"2015-08-01","value":"Aug 01, 2015"},{"key":"2015-07-25","value":"Jul 25, 2015"},{"key":"2015-07-18","value":"Jul 18, 2015"},{"key":"2015-07-11","value":"Jul 11, 2015"},{"key":"2015-07-04","value":"Jul 04, 2015"},{"key":"2015-06-27","value":"Jun 27, 2015"},{"key":"2015-06-20","value":"Jun 20, 2015"},{"key":"2015-06-13","value":"Jun 13, 2015"},{"key":"2015-06-06","value":"Jun 06, 2015"},{"key":"2015-05-30","value":"May 30, 2015"},{"key":"2015-05-23","value":"May 23, 2015"},{"key":"2015-05-16","value":"May 16, 2015"},{"key":"2015-05-09","value":"May 09, 2015"},{"key":"2015-05-02","value":"May 02, 2015"},{"key":"2015-04-25","value":"Apr 25, 2015"},{"key":"2015-04-18","value":"Apr 18, 2015"},{"key":"2015-04-11","value":"Apr 11, 2015"},{"key":"2015-04-04","value":"Apr 04, 2015"},{"key":"2015-03-28","value":"Mar 28, 2015"},{"key":"2015-03-21","value":"Mar 21, 2015"},{"key":"2015-03-14","value":"Mar 14, 2015"},{"key":"2015-03-07","value":"Mar 07, 2015"},{"key":"2015-02-28","value":"Feb 28, 2015"},{"key":"2015-02-21","value":"Feb 21, 2015"},{"key":"2015-02-14","value":"Feb 14, 2015"},{"key":"2015-02-07","value":"Feb 07, 2015"},{"key":"2015-01-31","value":"Jan 31, 2015"},{"key":"2015-01-24","value":"Jan 24, 2015"},{"key":"2015-01-17","value":"Jan 17, 2015"},{"key":"2015-01-10","value":"Jan 10, 2015"},{"key":"2015-01-03","value":"Jan 03, 2015"},{"key":"2014-12-27","value":"Dec 27, 2014"},{"key":"2014-12-20","value":"Dec 20, 2014"},{"key":"2014-12-13","value":"Dec 13, 2014"},{"key":"2014-12-06","value":"Dec 06, 2014"},{"key":"2014-11-29","value":"Nov 29, 2014"},{"key":"2014-11-22","value":"Nov 22, 2014"},{"key":"2014-11-15","value":"Nov 15, 2014"},{"key":"2014-11-08","value":"Nov 08, 2014"},{"key":"2014-11-01","value":"Nov 01, 2014"},{"key":"2014-10-25","value":"Oct 25, 2014"},{"key":"2014-10-18","value":"Oct 18, 2014"},{"key":"2014-10-11","value":"Oct 11, 2014"},{"key":"2014-10-04","value":"Oct 04, 2014"},{"key":"2014-09-27","value":"Sep 27, 2014"},{"key":"2014-09-20","value":"Sep 20, 2014"},{"key":"2014-09-13","value":"Sep 13, 2014"},{"key":"2014-09-06","value":"Sep 06, 2014"},{"key":"2014-08-30","value":"Aug 30, 2014"},{"key":"2014-08-23","value":"Aug 23, 2014"},{"key":"2014-08-16","value":"Aug 16, 2014"},{"key":"2014-08-09","value":"Aug 09, 2014"},{"key":"2014-08-02","value":"Aug 02, 2014"},{"key":"2014-07-26","value":"Jul 26, 2014"},{"key":"2014-07-19","value":"Jul 19, 2014"},{"key":"2014-07-12","value":"Jul 12, 2014"},{"key":"2014-07-05","value":"Jul 05, 2014"},{"key":"2014-06-28","value":"Jun 28, 2014"},{"key":"2014-06-21","value":"Jun 21, 2014"},{"key":"2014-06-14","value":"Jun 14, 2014"},{"key":"2014-06-07","value":"Jun 07, 2014"},{"key":"2014-05-31","value":"May 31, 2014"},{"key":"2014-05-24","value":"May 24, 2014"},{"key":"2014-05-17","value":"May 17, 2014"},{"key":"2014-05-10","value":"May 10, 2014"},{"key":"2014-05-03","value":"May 03, 2014"},{"key":"2014-04-26","value":"Apr 26, 2014"},{"key":"2014-04-19","value":"Apr 19, 2014"},{"key":"2014-04-12","value":"Apr 12, 2014"},{"key":"2014-04-05","value":"Apr 05, 2014"},{"key":"2014-03-29","value":"Mar 29, 2014"},{"key":"2014-03-22","value":"Mar 22, 2014"},{"key":"2014-03-15","value":"Mar 15, 2014"},{"key":"2014-03-08","value":"Mar 08, 2014"},{"key":"2014-03-01","value":"Mar 01, 2014"},{"key":"2014-02-22","value":"Feb 22, 2014"},{"key":"2014-02-15","value":"Feb 15, 2014"},{"key":"2014-02-08","value":"Feb 08, 2014"},{"key":"2014-02-01","value":"Feb 01, 2014"},{"key":"2014-01-25","value":"Jan 25, 2014"},{"key":"2014-01-18","value":"Jan 18, 2014"},{"key":"2014-01-11","value":"Jan 11, 2014"},{"key":"2014-01-04","value":"Jan 04, 2014"},{"key":"2013-12-28","value":"Dec 28, 2013"},{"key":"2013-12-21","value":"Dec 21, 2013"},{"key":"2013-12-14","value":"Dec 14, 2013"},{"key":"2013-12-07","value":"Dec 07, 2013"},{"key":"2013-11-30","value":"Nov 30, 2013"},{"key":"2013-11-23","value":"Nov 23, 2013"},{"key":"2013-11-16","value":"Nov 16, 2013"},{"key":"2013-11-09","value":"Nov 09, 2013"},{"key":"2013-11-02","value":"Nov 02, 2013"},{"key":"2013-10-26","value":"Oct 26, 2013"},{"key":"2013-10-19","value":"Oct 19, 2013"},{"key":"2013-10-12","value":"Oct 12, 2013"},{"key":"2013-10-05","value":"Oct 05, 2013"},{"key":"2013-09-28","value":"Sep 28, 2013"},{"key":"2013-09-21","value":"Sep 21, 2013"},{"key":"2013-09-14","value":"Sep 14, 2013"},{"key":"2013-09-07","value":"Sep 07, 2013"},{"key":"2013-08-31","value":"Aug 31, 2013"},{"key":"2013-08-24","value":"Aug 24, 2013"},{"key":"2013-08-17","value":"Aug 17, 2013"},{"key":"2013-08-10","value":"Aug 10, 2013"},{"key":"2013-08-03","value":"Aug 03, 2013"}];
	//console.log("Current Week: " + JSON.stringify(listData));
	return listData;
}