var express = require('express');

var app = express();
app.use('/', express.static('./static'));

require('./fraudRoute')(app);

app.listen(3333);